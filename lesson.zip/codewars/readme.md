- 字符串的replace方法
  replaceAll 按规则来格式化文本
- coderwars  社交化的代码能力训练平台 API+ 思维训练 让代码更漂亮
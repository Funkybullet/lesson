## 图片
image:重要的图片，例如公司的logo
background: 

## bfc
overflow:hidden; 创建一个 bfc 的区域